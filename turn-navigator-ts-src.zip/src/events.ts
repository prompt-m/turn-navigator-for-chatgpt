// events.ts
(() => {
  "use strict";
  const SH = window.CGTN_SHARED || {};
  const UI = window.CGTN_UI || {};
  const LG = window.CGTN_LOGIC || {};
  const NS = (window.CGTN_EVENTS = window.CGTN_EVENTS || {});

  // ★追加: 世代管理カウンター（関数の外に置いてください）
  let listToggleGen = 0;
  function bindEvents() {
    const box = document.getElementById("cgpt-nav");
    if (!box) return;

    // Changeイベント (トグルスイッチ) - 変更なし
    box.addEventListener("change", (e) => {
      const t = e.target;
      if (!(t instanceof HTMLInputElement)) return;
      // ▼ 一覧表示トグル (#cgpt-list-toggle)
      if (t.id === "cgpt-list-toggle") {
        const on = t.checked;
        const btn = document.getElementById("cgpt-list-btn");
        if (btn) btn.classList.toggle("active", on);
        // ★ 今回のクリックに番号を振る
        const myGen = ++listToggleGen;
        if (on) {
          // 1. Loading表示
          UI.updateStatusDisplay?.("List Gen...");

          // 2. 遅延実行
          setTimeout(async () => {
            // ★チェック: 待っている間に別のクリックがあったら、もう何もしない
            if (myGen !== listToggleGen) return;

            try {
              if (typeof LG.setListEnabled === "function") {
                // ここで待機。途中でOFFにされると、logic側のキャンセル機能により
                // この await はすぐに false で返ってくる
                await LG.setListEnabled(true);
              }
            } catch (err) {
              LG.logError?.("List Gen Failed", err);
            }

            // ★チェック: 処理が終わった後も、まだ自分が最新世代か確認
            if (myGen === listToggleGen) {
              if (typeof LG.updateStatus === "function") LG.updateStatus();
            }
          }, 50);
        } else {
          // OFFにする時
          // ★ logic側で古いON処理をキャンセルしてくれるので、ここは投げるだけでOK
          if (typeof LG.setListEnabled === "function") {
            LG.setListEnabled(false);
          }
          // 即座に数値更新
          if (typeof LG.updateStatus === "function") LG.updateStatus();
        }
      }

      if (t.id === "cgpt-viz") {
        const on = t.checked;
        if (typeof SH.toggleViz === "function") SH.toggleViz(on);
        SH.saveSettingsPatch?.({ showViz: on });
      }
    });

    // Clickイベント
    box.addEventListener("click", (e) => {
      const t = e.target;
      const el =
        t instanceof Element
          ? t.closest("button, label, input, .cgtn-ver")
          : null;
      if (!el) return;

      // ★追加: バージョン番号(.cgtn-ver)をクリックでログ表示
      if (el.classList.contains("cgtn-ver")) {
        e.preventDefault();
        e.stopPropagation();
        if (typeof LG.showLogs === "function") LG.showLogs();
        return;
      }

      // 設定ボタン
      if (el.id === "cgtn-open-settings") {
        if (typeof UI.openSettingsModal === "function") {
          e.preventDefault();
          UI.openSettingsModal();
        } else {
          try {
            chrome.runtime.sendMessage({ cmd: "openOptions" });
          } catch (_) {
            window.open(chrome.runtime.getURL("options.html"), "_blank");
          }
        }
        return;
      }

      // ★修正: 更新ボタン
      if (el.id === "cgpt-navi-refresh") {
        e.preventDefault();

        // 1. "Refresh..." と表示
        console.log(" updateStatusDisplay Refresh...");
        UI.updateStatusDisplay?.("Refresh...");

        // 2. UI描画をブロックしないよう少し待ってから処理開始
        setTimeout(async () => {
          try {
            if (typeof LG.rebuild === "function") LG.rebuild();
            if (SH.isListOpen?.() && typeof LG.renderList === "function") {
              await LG.renderList(true);
            }
          } catch (err) {
            // エラー時はログに保存
            LG.logError?.("Refresh Failed", err);
          } finally {
            // 3. 終わったら数値表示に戻す
            LG.updateStatus?.();
          }
        }, 50);
        return;
      }

      // ナビゲーションボタン
      if (el instanceof HTMLElement && el.dataset.act) {
        const act = el.dataset.act;
        const grp = el.closest(".cgpt-nav-group");
        const role =
          (grp instanceof HTMLElement ? grp.dataset.role : null) || "all";
        switch (act) {
          case "top":
            LG.goTop?.(role);
            break;
          case "bottom":
            LG.goBottom?.(role);
            break;
          case "next":
            LG.goNext?.(role);
            break;
          case "prev":
            LG.goPrev?.(role);
            break;
        }
      }
    });

    // ★ここに追加: 隠し機能「ターン数をダブルクリックでログ表示」
    // ナビパネルが後から描画されても確実に動くように、bodyで待ち受けます
    document.body.addEventListener("dblclick", (e) => {
      const target = e.target as HTMLElement;
      console.log("double-clicked target:", target);

      // クリックされた場所が「モニター(数字部分)」の内側かどうか判定
      //const monitor = target.closest("#cgtn-status-monitor");
      // 修正: ターゲットを「モニター」から「その他ラベル」に変更
      // "others" という i18n属性を持つ要素を探す
      const trigger = target.closest('[data-i18n="others"]');

      if (trigger) {
        e.preventDefault();
        e.stopPropagation();

        console.log("trigger double-clicked!"); // デバッグ用ログ

        // shared.ts の showLogs を呼び出す
        const SH = window.CGTN_SHARED;
        if (typeof SH.showLogs === "function") {
          SH.showLogs();
        } else {
          alert("Log viewer is not available.");
        }
      }
    });
  }

  // ============================================================
  // ★追加: Universal版ロジックの移植 (簡易高速スキャン) 2026.01.30
  // ============================================================
  NS.runFastUniversalScan = function () {
    // 1. 記事要素を単純取得 (Universal版と同じアプローチ)
    const articles = document.querySelectorAll("article");
    const total = articles.length;

    if (total === 0) return false; // まだDOMがない

    // 2. 現在地をざっくり計算 (スクロール位置から推定)
    //    Universal版が行っている「中央付近の要素を探す」処理の簡易版です
    let current = 0;
    const center = window.innerHeight / 2;

    // 全要素ループは重いので、バイナリサーチや軽量探索が理想ですが
    // Universal版同様、単純ループでもDOM操作よりは遥かに速いです
    for (let i = 0; i < total; i++) {
      const rect = articles[i].getBoundingClientRect();
      // 画面内に入ってきたらそれを現在地とする
      if (rect.top < center && rect.bottom > 0) {
        current = i + 1;
      }
      // 画面より下に行ったら終了
      if (rect.top > window.innerHeight) break;
    }
    // 見つからなければ最後尾または1
    if (current === 0) current = total;

    // 3. UIを直接更新 (正規のデータ構築を待たない)
    window.CGTN_UI?.updateStatusDisplay?.(`${current} / ${total}`);

    // スクロール連動用に簡易的にスパイを登録しておく（チラつき防止）
    // (正規のLogicが走るまでの繋ぎです)
    return true;
  };

  NS.bindEvents = bindEvents;
})();
